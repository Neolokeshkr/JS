function someFunc(){
	fname : "Lokesh",
	lName : "Kumar",
	fullName : function(){
		return (fName+" "+lName)
	}
}
